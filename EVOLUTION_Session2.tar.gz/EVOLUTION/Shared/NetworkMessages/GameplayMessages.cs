using System;
using Shared.NetworkMessages;

namespace Shared.NetworkMessages.Gameplay
{
    /// <summary>
    /// Player movement message - sent frequently (unreliable)
    /// </summary>
    [Serializable]
    public class PlayerMoveMessage : UnreliableMessage
    {
        public override MessageType Type => MessageType.PlayerMove;
        public string PlayerId { get; set; }
        public float X { get; set; }
        public float Y { get; set; }
        public float VelocityX { get; set; }
        public float VelocityY { get; set; }
        public float Rotation { get; set; }
        
        public PlayerMoveMessage() { }
        
        public PlayerMoveMessage(string playerId, float x, float y, float velX, float velY, float rotation)
        {
            PlayerId = playerId;
            X = x;
            Y = y;
            VelocityX = velX;
            VelocityY = velY;
            Rotation = rotation;
            Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        }
    }
    
    /// <summary>
    /// Player attack message - reliable
    /// </summary>
    [Serializable]
    public class PlayerAttackMessage : ReliableMessage
    {
        public override MessageType Type => MessageType.PlayerAttack;
        public string PlayerId { get; set; }
        public float TargetX { get; set; }
        public float TargetY { get; set; }
        public bool IsManualAim { get; set; }
        public int AbilitySlot { get; set; }
        
        public PlayerAttackMessage() { }
        
        public PlayerAttackMessage(string playerId, float targetX, float targetY, bool manualAim, int abilitySlot)
        {
            PlayerId = playerId;
            TargetX = targetX;
            TargetY = targetY;
            IsManualAim = manualAim;
            AbilitySlot = abilitySlot;
            Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        }
    }
    
    /// <summary>
    /// Player damage taken message
    /// </summary>
    [Serializable]
    public class PlayerDamageMessage : ReliableMessage
    {
        public override MessageType Type => MessageType.PlayerDamage;
        public string VictimId { get; set; }
        public string AttackerId { get; set; }
        public float Damage { get; set; }
        public int DamageType { get; set; }
        public float CurrentHealth { get; set; }
        public float MaxHealth { get; set; }
        
        public PlayerDamageMessage() { }
        
        public PlayerDamageMessage(string victim, string attacker, float damage, int dmgType, float currHP, float maxHP)
        {
            VictimId = victim;
            AttackerId = attacker;
            Damage = damage;
            DamageType = dmgType;
            CurrentHealth = currHP;
            MaxHealth = maxHP;
            Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        }
    }
    
    /// <summary>
    /// Player death message
    /// </summary>
    [Serializable]
    public class PlayerDeathMessage : ReliableMessage
    {
        public override MessageType Type => MessageType.PlayerDeath;
        public string PlayerId { get; set; }
        public string KillerId { get; set; }
        public float RespawnTime { get; set; }
        
        public PlayerDeathMessage() { }
        
        public PlayerDeathMessage(string playerId, string killerId, float respawnTime)
        {
            PlayerId = playerId;
            KillerId = killerId;
            RespawnTime = respawnTime;
            Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        }
    }
    
    /// <summary>
    /// Match start message
    /// </summary>
    [Serializable]
    public class MatchStartMessage : ReliableMessage
    {
        public override MessageType Type => MessageType.MatchStart;
        public string MatchId { get; set; }
        public int GameMode { get; set; }
        public float Duration { get; set; }
        public PlayerInfo[] Players { get; set; }
        
        public MatchStartMessage() { }
        
        public MatchStartMessage(string matchId, int mode, float duration, PlayerInfo[] players)
        {
            MatchId = matchId;
            GameMode = mode;
            Duration = duration;
            Players = players;
            Timestamp = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        }
    }
    
    /// <summary>
    /// Player info for network messages
    /// </summary>
    [Serializable]
    public class PlayerInfo
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int TeamId { get; set; }
        public int HeroId { get; set; }
        public int SkinIndex { get; set; }
        public float SpawnX { get; set; }
        public float SpawnY { get; set; }
    }
}
